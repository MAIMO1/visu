package ru.pic.pic_visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Stick-figure skeleton ESP (CS2 style), animated with the player's walking and sneaking. */
public final class Skeleton {
    private static final int HEAD = 0, NECK = 1, CHEST = 2, PELVIS = 3, SHL = 4, SHR = 5, ELL = 6, ELR = 7,
            HAL = 8, HAR = 9, HIPL = 10, HIPR = 11, KNL = 12, KNR = 13, FTL = 14, FTR = 15;
    private static final int[][] BONES = {
            {NECK, CHEST}, {CHEST, PELVIS}, {NECK, SHL}, {NECK, SHR},
            {SHL, ELL}, {ELL, HAL}, {SHR, ELR}, {ELR, HAR},
            {PELVIS, HIPL}, {PELVIS, HIPR}, {HIPL, KNL}, {KNL, FTL}, {HIPR, KNR}, {KNR, FTR}
    };

    private static final double[][] J = new double[16][3];
    private static final float[][] CL = new float[17][4];
    private static final float[] SEG = new float[4];
    private static final float[] PT = new float[3];
    private static final float[] PT2 = new float[3];

    private Skeleton() {}

    private static double rx, ry, rz, fx, fz, bx, by, bz, lean, pelvisY;
    private static boolean sneak;

    /** Local -> world. lx right, ly up, lz forward. */
    private static void put(int i, double lx, double ly, double lz) {
        if (sneak && ly > pelvisY + 0.01) {
            double k = (ly - pelvisY) / 0.65;
            ly = pelvisY + (ly - pelvisY) * 0.9;
            lz += 0.22 * k;
        }
        if (lean != 0) {
            double rel = ly - pelvisY;
            double ny = rel * Math.cos(lean) - lz * Math.sin(lean);
            double nz = rel * Math.sin(lean) + lz * Math.cos(lean);
            ly = pelvisY + ny;
            lz = nz;
        }
        J[i][0] = bx + lx * rx + lz * fx;
        J[i][1] = by + ly;
        J[i][2] = bz + lx * rz + lz * fz;
    }

    private static void compute(AbstractClientPlayerEntity p, float td) {
        Vec3d pos = p.getLerpedPos(td);
        bx = pos.x; by = pos.y; bz = pos.z;
        double yaw = Math.toRadians(MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw));
        double sy = Math.sin(yaw), cy = Math.cos(yaw);
        fx = -sy; fz = cy;       // forward
        rx = -cy; rz = -sy;      // right
        sneak = p.isSneaking();
        pelvisY = sneak ? 0.62 : 0.75;
        lean = 0;
        String poseName = p.getPose().name();
        boolean gliding = poseName.equals("GLIDING") || poseName.equals("FALL_FLYING");
        if (p.isInSwimmingPose() || gliding) {
            lean = Math.toRadians(90.0 + p.getPitch(td));
            sneak = false;
            pelvisY = 0.75;
        }
        float limbPos = p.limbAnimator.getPos(td);
        float limbSpeed = Math.min(1f, p.limbAnimator.getSpeed(td));
        double legR = Math.cos(limbPos * 0.6662f) * 1.3 * limbSpeed * 0.8;
        double armR = Math.cos(limbPos * 0.6662f + Math.PI) * 1.0 * limbSpeed;
        double[] legA = {-legR, legR};   // left, right
        double[] armA = {-armR, armR};

        put(PELVIS, 0, pelvisY, 0);
        put(CHEST, 0, pelvisY + 0.40, 0);
        put(NECK, 0, pelvisY + 0.65, 0);
        put(HEAD, 0, pelvisY + 0.87, sneak ? 0.04 : 0);

        for (int s = 0; s < 2; s++) {
            double side = s == 0 ? -1 : 1;
            int hip = s == 0 ? HIPL : HIPR, kn = s == 0 ? KNL : KNR, ft = s == 0 ? FTL : FTR;
            int sh = s == 0 ? SHL : SHR, el = s == 0 ? ELL : ELR, ha = s == 0 ? HAL : HAR;
            double a = legA[s];
            double hx = 0.12 * side;
            double kneeY = pelvisY - 0.375 * Math.cos(a * 0.5), kneeZ = 0.375 * Math.sin(a * 0.5);
            double footY = kneeY - 0.375 * Math.cos(a), footZ = kneeZ + 0.375 * Math.sin(a);
            put(hip, hx, pelvisY, 0);
            put(kn, hx, kneeY, kneeZ);
            put(ft, hx, Math.max(0, footY), footZ);

            double b = armA[s];
            double sx = 0.31 * side, sY = pelvisY + 0.65;
            double elY = sY - 0.30 * Math.cos(b * 0.6), elZ = 0.30 * Math.sin(b * 0.6);
            double haY = elY - 0.30 * Math.cos(b), haZ = elZ + 0.30 * Math.sin(b) + 0.08 * Math.max(0, b);
            put(sh, sx, sY, 0);
            put(el, sx, elY, elZ);
            put(ha, sx, haY, haZ);
        }
    }

    public static void draw(DrawContext ctx, Config c, AbstractClientPlayerEntity p, int col, float px) {
        compute(p, Proj.td);
        col |= 0xFF000000;
        int core = Colors.lerp(col, 0xFFFFFFFF, 0.5f);
        float th = Math.max(1f, c.espThickness) * px;

        for (int i = 0; i < 16; i++) Proj.toClip(J[i][0], J[i][1], J[i][2], CL[i]);

        if (c.espGlow) {
            for (int[] b : BONES) {
                if (!Proj.clipEdge(CL[b[0]], CL[b[1]], SEG, 0)) continue;
                Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th * 4.6f, Colors.withAlpha(col, 0.10f));
                Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th * 2.4f, Colors.withAlpha(col, 0.20f));
            }
        }
        for (int[] b : BONES) {
            if (!Proj.clipEdge(CL[b[0]], CL[b[1]], SEG, 0)) continue;
            Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th, core);
        }

        if (c.skeletonJoints) {
            int r = Math.max(2, Math.round(th * 1.25f));
            for (int i = 1; i < 16; i++) {
                if (!Proj.project(J[i][0], J[i][1], J[i][2], PT)) continue;
                Gfx.circle(ctx, Math.round(PT[0]), Math.round(PT[1]), r, core);
            }
        }

        if (c.skeletonHead && Proj.project(J[HEAD][0], J[HEAD][1], J[HEAD][2], PT)) {
            int r = Math.max(4, Math.round(0.23f * Proj.pxPerUnit / PT[2]));
            int bw = Math.max(1, Math.round(th));
            int cx = Math.round(PT[0]), cy = Math.round(PT[1]);
            if (c.espGlow) {
                Gfx.rrectRing(ctx, cx - r - bw * 2, cy - r - bw * 2, (r + bw * 2) * 2, (r + bw * 2) * 2, r + bw * 2, bw * 3, Colors.withAlpha(col, 0.14f));
            }
            Gfx.rrectRing(ctx, cx - r, cy - r, r * 2, r * 2, r, bw, core);
        }

        if (c.skeletonGaze) {
            Vec3d look = p.getRotationVec(Proj.td);
            double hx = J[HEAD][0], hy = J[HEAD][1], hz = J[HEAD][2];
            Proj.toClip(hx, hy, hz, CL[16]);
            Proj.toClip(hx + look.x * 0.7, hy + look.y * 0.7, hz + look.z * 0.7, CL[15]);
            if (Proj.clipEdge(CL[16], CL[15], SEG, 0)) {
                Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], Math.max(1f, th * 0.8f), Colors.withAlpha(0xFFFFFFFF, 0.8f));
            }
        }
    }
}
