package ru.pic.pic_visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import ru.pic.pic_visuals.Widgets.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** All modules (cards in the menu) with their settings, plus key-bind handling. */
public final class Modules {
    public enum Cat {
        VISUALS(L.of("Visuals", "Визуалы")),
        EFFECTS(L.of("Effects", "Эффекты")),
        HUD(L.of("HUD", "Интерфейс")),
        THEME(L.of("Theme", "Тема"));
        public final L label;
        Cat(L l) { label = l; }
    }

    public static final class Mod {
        public final String name;
        public final Cat cat;
        public final BooleanSupplier on;      // null = always on, no checkbox
        public final Consumer<Boolean> set;
        public final List<Row> rows = new ArrayList<>();
        public final L desc;
        public boolean expanded = true;
        public float anim = -1f;
        public final Row enableRow;
        boolean bindWasDown = false;

        Mod(String name, Cat cat, L desc, BooleanSupplier on, Consumer<Boolean> set) {
            this.name = name;
            this.cat = cat;
            this.desc = desc;
            this.on = on;
            this.set = set;
            this.enableRow = on == null ? null
                    : new ToggleRow(L.of("Enable", "Включить"), desc, on, set, () -> expanded = !expanded);
        }

        public boolean toggleable() { return on != null; }
    }

    private static List<Mod> ALL;

    private Modules() {}

    public static synchronized List<Mod> all() {
        if (ALL == null) ALL = build();
        return ALL;
    }

    public static List<Mod> of(Cat cat) {
        List<Mod> out = new ArrayList<>();
        for (Mod m : all()) if (m.cat == cat) out.add(m);
        return out;
    }

    // ------------------------------------------------------------------ key binds

    public static void pollBinds(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.player == null) return;
        Config c = Config.get();
        long h = mc.getWindow().getHandle();
        for (Mod m : all()) {
            if (!m.toggleable()) continue;
            Integer key = c.binds.get(m.name);
            if (key == null || key < 0) { m.bindWasDown = false; continue; }
            boolean down = InputUtil.isKeyPressed(h, key);
            if (down && !m.bindWasDown) m.set.accept(!m.on.getAsBoolean());
            m.bindWasDown = down;
        }
    }

    public static String bindLabel(Mod m) {
        Integer key = Config.get().binds.get(m.name);
        if (key == null || key < 0) return "N/A";
        try {
            String s = InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
            return s.length() > 6 ? s.substring(0, 6) : s;
        } catch (Exception e) {
            return "?";
        }
    }

    // ------------------------------------------------------------------ builders

    private static L l(String en, String ru) { return L.of(en, ru); }

    private static Row tog(String en, String ru, String dEn, String dRu, BooleanSupplier g, Consumer<Boolean> s) {
        return new ToggleRow(l(en, ru), l(dEn, dRu), g, s, null);
    }

    private static Row sld(String en, String ru, String dEn, String dRu, float min, float max, float step, String fmt,
                           java.util.function.Supplier<Float> g, Consumer<Float> s) {
        return new SliderRow(l(en, ru), l(dEn, dRu), min, max, step, fmt, g, s);
    }

    private static Row col(String en, String ru, String dEn, String dRu, java.util.function.IntSupplier g, java.util.function.IntConsumer s) {
        return new ColorRow(l(en, ru), l(dEn, dRu), g, s);
    }

    private static Row shapes(Config.PSet s) {
        List<BooleanSupplier> g = new ArrayList<>();
        List<Consumer<Boolean>> st = new ArrayList<>();
        g.add(() -> s.star);   st.add(v -> s.star = v);
        g.add(() -> s.circle); st.add(v -> s.circle = v);
        g.add(() -> s.dollar); st.add(v -> s.dollar = v);
        g.add(() -> s.letterN); st.add(v -> s.letterN = v);
        g.add(() -> s.heart);  st.add(v -> s.heart = v);
        return new ChipsRow(l("Shapes", "Формы"), l("Star, circle, dollar, N, heart", "Звезда, круг, доллар, N, сердце"),
                new int[]{Gfx.SHAPE_STAR, Gfx.SHAPE_CIRCLE, Gfx.SHAPE_DOLLAR, Gfx.SHAPE_N, Gfx.SHAPE_HEART}, g, st);
    }

    private static void colorRows(List<Row> r, Config.PSet s) {
        r.add(new EnumRow<>(l("Color", "Цвет"), l("Theme, rainbow or your own colors", "Тема, радуга или свои цвета"),
                Config.PColor.values(), () -> s.colorMode, v -> s.colorMode = v));
        r.add(col("Custom color 1", "Свой цвет 1", "Used in Custom mode", "Для режима Custom", () -> s.colorA, v -> s.colorA = v));
        r.add(col("Custom color 2", "Свой цвет 2", "Particles blend between both", "Частицы смешивают оба цвета", () -> s.colorB, v -> s.colorB = v));
    }

    private static void glowRows(List<Row> r, Config.PSet s) {
        r.add(tog("Glow", "Свечение", "Soft halo around every particle", "Мягкий ореол вокруг частиц", () -> s.glow, v -> s.glow = v));
        r.add(sld("Glow strength", "Сила свечения", "", "", 0.05f, 1f, 0.05f, "%.2f", () -> s.glowAlpha, v -> s.glowAlpha = v));
    }

    private static List<Mod> build() {
        Config c = Config.get();
        List<Mod> out = new ArrayList<>();

        // ---------------- Visuals ----------------
        Mod esp = new Mod("ESP", Cat.VISUALS, l("Highlights players through walls", "Подсветка игроков сквозь стены"),
                () -> c.espEnabled, v -> c.espEnabled = v);
        esp.rows.add(new EnumRow<>(l("Style", "Стиль"), l("Glass 3D, wire, 2D box, corners or skeleton", "Стекло 3D, каркас, 2D бокс, углы или скелет"),
                Config.EspStyle.values(), () -> c.espStyle, v -> c.espStyle = v));
        esp.rows.add(tog("Fill", "Заливка", "Translucent faces of the box", "Полупрозрачные грани бокса", () -> c.espFill, v -> c.espFill = v));
        esp.rows.add(sld("Fill opacity", "Прозрачность", "", "", 0.05f, 0.7f, 0.01f, "%.2f", () -> c.fillOpacity, v -> c.fillOpacity = v));
        esp.rows.add(sld("Thickness", "Толщина", "Edge and bone thickness", "Толщина линий и костей", 1f, 5f, 0.5f, "%.1f", () -> c.espThickness, v -> c.espThickness = v));
        esp.rows.add(tog("Soft glow", "Свечение", "Glowing halo around lines", "Мягкое свечение вокруг линий", () -> c.espGlow, v -> c.espGlow = v));
        esp.rows.add(tog("Dark outline", "Обводка", "For the 2D styles", "Для 2D стилей", () -> c.espOutline, v -> c.espOutline = v));
        esp.rows.add(tog("Skeleton head", "Голова скелета", "Draws a ring for the head", "Рисует кольцо вместо головы", () -> c.skeletonHead, v -> c.skeletonHead = v));
        esp.rows.add(tog("Skeleton joints", "Суставы скелета", "Dots on every joint", "Точки на каждом суставе", () -> c.skeletonJoints, v -> c.skeletonJoints = v));
        esp.rows.add(tog("Skeleton gaze", "Взгляд скелета", "Line showing where the player looks", "Линия направления взгляда", () -> c.skeletonGaze, v -> c.skeletonGaze = v));
        out.add(esp);

        Mod inv = new Mod("Invisible", Cat.VISUALS, l("Reveals invisible players", "Показывает невидимых игроков"),
                () -> c.showInvisible, v -> c.showInvisible = v);
        inv.rows.add(tog("Own color", "Свой цвет", "Invisible players get their own color", "У невидимых свой цвет", () -> c.invisibleOwnColor, v -> c.invisibleOwnColor = v));
        inv.rows.add(col("Color", "Цвет", "", "", () -> c.invisibleColor, v -> c.invisibleColor = v));
        out.add(inv);

        Mod tags = new Mod("Nametags", Cat.VISUALS, l("Name, health and distance above players", "Ник, здоровье и дистанция над игроками"),
                () -> c.nametag, v -> c.nametag = v);
        tags.rows.add(tog("Health", "Здоровье", "", "", () -> c.nameHealth, v -> c.nameHealth = v));
        tags.rows.add(tog("Distance", "Дистанция", "", "", () -> c.nameDistance, v -> c.nameDistance = v));
        tags.rows.add(tog("Background", "Фон", "", "", () -> c.nameBg, v -> c.nameBg = v));
        tags.rows.add(sld("Scale", "Размер", "", "", 0.6f, 2f, 0.05f, "%.2f", () -> c.nametagScale, v -> c.nametagScale = v));
        out.add(tags);

        out.add(new Mod("Health Bar", Cat.VISUALS, l("Slim health bar next to the box", "Тонкая полоска здоровья у бокса"),
                () -> c.healthBar, v -> c.healthBar = v));
        out.add(new Mod("Tracers", Cat.VISUALS, l("Line from the screen bottom to each player", "Линия от низа экрана к каждому игроку"),
                () -> c.tracers, v -> c.tracers = v));
        out.add(new Mod("Held Item", Cat.VISUALS, l("Shows the item a player holds", "Показывает предмет в руке игрока"),
                () -> c.showItem, v -> c.showItem = v));
        out.add(new Mod("Self", Cat.VISUALS, l("Draws the ESP on you in third person", "Рисует ESP на тебе в третьем лице"),
                () -> c.showSelf, v -> c.showSelf = v));

        // ---------------- Effects ----------------
        Mod wp = new Mod("World Particles", Cat.EFFECTS, l("Stars, circles, dollars and N floating around you", "Звёзды, круги, доллары и N вокруг тебя"),
                () -> c.world.enabled, v -> c.world.enabled = v);
        wp.rows.add(shapes(c.world));
        wp.rows.add(sld("Amount", "Количество", "How many particles exist at once", "Сколько частиц одновременно", 10f, 400f, 5f, "%.0f", () -> c.world.count, v -> c.world.count = v));
        wp.rows.add(sld("Radius", "Радиус", "Spawn area around you", "Область вокруг тебя", 4f, 40f, 1f, "%.0f", () -> c.world.radius, v -> c.world.radius = v));
        wp.rows.add(sld("Size", "Размер", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.world.size, v -> c.world.size = v));
        wp.rows.add(sld("Speed", "Скорость", "", "", 0.1f, 3f, 0.1f, "%.1f", () -> c.world.speed, v -> c.world.speed = v));
        wp.rows.add(sld("Lifetime", "Время жизни", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.world.life, v -> c.world.life = v));
        wp.rows.add(sld("Spin", "Вращение", "", "", 0f, 3f, 0.1f, "%.1f", () -> c.world.spin, v -> c.world.spin = v));
        wp.rows.add(sld("Opacity", "Прозрачность", "", "", 0.1f, 1f, 0.05f, "%.2f", () -> c.world.alpha, v -> c.world.alpha = v));
        wp.rows.add(tog("Twinkle", "Мерцание", "", "", () -> c.world.twinkle, v -> c.world.twinkle = v));
        glowRows(wp.rows, c.world);
        colorRows(wp.rows, c.world);
        wp.rows.add(tog("Shooting stars", "Падающие звёзды", "Fast stars with a tail in the sky", "Быстрые звёзды с хвостом в небе", () -> c.shootingStars, v -> c.shootingStars = v));
        wp.rows.add(tog("Hide behind blocks", "Прятать за блоками", "Particles do not show through walls", "Частицы не видны сквозь стены", () -> c.hideBehindBlocks, v -> c.hideBehindBlocks = v));
        out.add(wp);

        Mod hp = new Mod("Hit Particles", Cat.EFFECTS, l("Particle burst when you hit something", "Взрыв частиц при ударе"),
                () -> c.hit.enabled, v -> c.hit.enabled = v);
        hp.rows.add(shapes(c.hit));
        hp.rows.add(sld("Amount", "Количество", "Particles per hit", "Частиц за удар", 4f, 100f, 1f, "%.0f", () -> c.hit.count, v -> c.hit.count = v));
        hp.rows.add(sld("Size", "Размер", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.hit.size, v -> c.hit.size = v));
        hp.rows.add(sld("Speed", "Скорость", "", "", 0.1f, 3f, 0.1f, "%.1f", () -> c.hit.speed, v -> c.hit.speed = v));
        hp.rows.add(sld("Gravity", "Гравитация", "", "", 0f, 2f, 0.1f, "%.1f", () -> c.hit.gravity, v -> c.hit.gravity = v));
        hp.rows.add(sld("Lifetime", "Время жизни", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.hit.life, v -> c.hit.life = v));
        hp.rows.add(sld("Spin", "Вращение", "", "", 0f, 3f, 0.1f, "%.1f", () -> c.hit.spin, v -> c.hit.spin = v));
        hp.rows.add(sld("Opacity", "Прозрачность", "", "", 0.1f, 1f, 0.05f, "%.2f", () -> c.hit.alpha, v -> c.hit.alpha = v));
        glowRows(hp.rows, c.hit);
        colorRows(hp.rows, c.hit);
        hp.rows.add(tog("Kill burst", "Взрыв при убийстве", "Bigger burst when the target dies", "Большой взрыв, когда цель умирает", () -> c.killBurst, v -> c.killBurst = v));
        out.add(hp);

        Mod tr = new Mod("Trails", Cat.EFFECTS, l("Particles behind you while you move", "Частицы за тобой при движении"),
                () -> c.trail.enabled, v -> c.trail.enabled = v);
        tr.rows.add(shapes(c.trail));
        tr.rows.add(sld("Rate", "Частота", "Particles per second", "Частиц в секунду", 5f, 150f, 5f, "%.0f", () -> c.trail.count, v -> c.trail.count = v));
        tr.rows.add(sld("Size", "Размер", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.trail.size, v -> c.trail.size = v));
        tr.rows.add(sld("Speed", "Скорость", "", "", 0.1f, 3f, 0.1f, "%.1f", () -> c.trail.speed, v -> c.trail.speed = v));
        tr.rows.add(sld("Lifetime", "Время жизни", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.trail.life, v -> c.trail.life = v));
        tr.rows.add(sld("Opacity", "Прозрачность", "", "", 0.1f, 1f, 0.05f, "%.2f", () -> c.trail.alpha, v -> c.trail.alpha = v));
        glowRows(tr.rows, c.trail);
        colorRows(tr.rows, c.trail);
        out.add(tr);

        Mod jc = new Mod("Jump Circles", Cat.EFFECTS, l("Glowing ring on the ground when you jump", "Светящееся кольцо на земле при прыжке"),
                () -> c.jump.enabled, v -> c.jump.enabled = v);
        jc.rows.add(sld("Radius", "Радиус", "", "", 0.5f, 4f, 0.1f, "%.1f", () -> c.jump.size, v -> c.jump.size = v));
        jc.rows.add(sld("Lifetime", "Время жизни", "", "", 0.3f, 3f, 0.1f, "%.1f", () -> c.jump.life, v -> c.jump.life = v));
        jc.rows.add(sld("Opacity", "Прозрачность", "", "", 0.1f, 1f, 0.05f, "%.2f", () -> c.jump.alpha, v -> c.jump.alpha = v));
        glowRows(jc.rows, c.jump);
        colorRows(jc.rows, c.jump);
        out.add(jc);

        Mod th = new Mod("Target HUD", Cat.EFFECTS, l("Face, name and health of your target", "Лицо, ник и здоровье цели"),
                () -> c.targetHud, v -> c.targetHud = v);
        th.rows.add(sld("Scale", "Размер", "", "", 0.6f, 1.8f, 0.05f, "%.2f", () -> c.targetHudScale, v -> c.targetHudScale = v));
        out.add(th);

        // ---------------- HUD ----------------
        Mod wm = new Mod("Watermark", Cat.HUD, l("Name, FPS, time and ping", "Ник, FPS, время и пинг"),
                () -> c.hudWatermark, v -> c.hudWatermark = v);
        wm.rows.add(sld("HUD scale", "Размер HUD", "Also scales the information panel", "Также меняет размер панели информации", 0.6f, 1.6f, 0.05f, "%.2f", () -> c.hudScale, v -> c.hudScale = v));
        out.add(wm);
        out.add(new Mod("Information", Cat.HUD, l("BPS, TPS, coordinates and ping", "BPS, TPS, координаты и пинг"),
                () -> c.hudInfo, v -> c.hudInfo = v));

        // ---------------- Theme ----------------
        Mod colors = new Mod("Colors", Cat.THEME, L.EMPTY, null, null);
        colors.rows.add(new PresetsRow(l("Presets", "Пресеты"), null));
        colors.rows.add(new EnumRow<>(l("Color mode", "Режим цвета"), l("How the ESP color is picked", "Как выбирается цвет ESP"),
                Config.ColorMode.values(), () -> c.colorMode, v -> c.colorMode = v));
        colors.rows.add(col("Primary", "Основной", "ESP and particles", "ESP и частицы", () -> c.colorA, v -> c.colorA = v));
        colors.rows.add(col("Secondary", "Второй", "Gradient partner", "Для градиента", () -> c.colorB, v -> c.colorB = v));
        colors.rows.add(col("Menu accent", "Акцент меню", "Color of the menu and target HUD", "Цвет меню и Target HUD", () -> c.uiAccent, v -> c.uiAccent = v));
        out.add(colors);

        Mod general = new Mod("General", Cat.THEME, L.EMPTY, null, null);
        general.rows.add(sld("Max distance", "Макс. дистанция", "ESP range in blocks", "Дальность ESP в блоках", 16f, 512f, 8f, "%.0f", () -> c.maxDistance, v -> c.maxDistance = v));
        general.rows.add(sld("Animation speed", "Скорость анимаций", "Rainbow and gradient speed", "Скорость радуги и градиента", 0.2f, 3f, 0.1f, "%.1f", () -> c.animSpeed, v -> c.animSpeed = v));
        out.add(general);

        return out;
    }
}
