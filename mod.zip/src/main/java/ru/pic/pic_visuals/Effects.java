package ru.pic.pic_visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Drives the particle effects: spawning, hit/kill bursts, trails, jump rings, shooting stars. */
public final class Effects {
    private static final Random RNG = new Random();
    private static long lastNs = 0L;
    public static float dt = 0.016f;

    public static Entity lastHit;
    public static long lastHitMs = 0L;
    private static boolean lastHitHandled = false;

    private static boolean wasOnGround = true;
    private static float trailAcc = 0f;
    private static float starTimer = 1.5f;

    private Effects() {}

    /** Called (client side) when the local player attacks an entity. */
    public static void onAttack(Entity e) {
        if (!(e instanceof LivingEntity)) return;
        Config c = Config.get();
        lastHit = e;
        lastHitMs = System.currentTimeMillis();
        lastHitHandled = false;
        if (c.hit.enabled) {
            Vec3d pos = e.getBoundingBox().getCenter();
            ParticleSys.burst(c, c.hit, pos, Math.round(c.hit.count), 1f, 1f);
        }
    }

    /** Client tick. */
    public static void tick(MinecraftClient mc) {
        Config c = Config.get();
        if (mc.player == null || mc.world == null) {
            wasOnGround = true;
            lastHit = null;
            return;
        }
        boolean og = mc.player.isOnGround();
        if (c.jump.enabled && wasOnGround && !og && mc.player.getVelocity().y > 0.1) {
            ParticleSys.ring(c, mc.player.getPos());
        }
        wasOnGround = og;

        if (lastHit instanceof LivingEntity le && !lastHitHandled) {
            if (!le.isAlive() || le.getHealth() <= 0f) {
                lastHitHandled = true;
                if (c.killBurst && c.hit.enabled) {
                    Vec3d pos = le.getBoundingBox().getCenter();
                    ParticleSys.burst(c, c.hit, pos, Math.round(c.hit.count * 2.5f), 1.7f, 1.35f);
                }
            }
        }
        if (lastHit != null && System.currentTimeMillis() - lastHitMs > 10000L) lastHit = null;
    }

    /** Once per rendered frame (before drawing). */
    public static void frame(MinecraftClient mc) {
        long now = System.nanoTime();
        dt = lastNs == 0L ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        Config c = Config.get();
        if (mc.player == null || mc.world == null) return;

        if (c.world.enabled) {
            int target = Math.round(c.world.count);
            int alive = ParticleSys.worldAlive();
            if (alive < target) ParticleSys.spawnWorld(c, mc, Math.min(8, target - alive));
            if (c.shootingStars) {
                starTimer -= dt;
                if (starTimer <= 0f) {
                    ParticleSys.shootingStar(c, mc);
                    starTimer = 1.2f + RNG.nextFloat() * 3.2f;
                }
            }
        }

        if (c.trail.enabled) {
            Vec3d v = mc.player.getVelocity();
            double hs = Math.hypot(v.x, v.z);
            if (hs > 0.04 || Math.abs(v.y) > 0.3) {
                trailAcc += dt * c.trail.count;
                int guard = 0;
                while (trailAcc >= 1f && guard++ < 12) {
                    trailAcc -= 1f;
                    ParticleSys.trailSpawn(c, mc.player.getLerpedPos(Proj.td));
                }
            } else {
                trailAcc = 0f;
            }
        }

        ParticleSys.update(dt);
    }
}
