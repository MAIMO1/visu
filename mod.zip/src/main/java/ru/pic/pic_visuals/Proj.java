package ru.pic.pic_visuals;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.Window;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;

/** World -> screen projection shared by the ESP, skeletons, particles and rings. */
public final class Proj {
    public static final float E = 0.05f;

    private static final Matrix4f PROJ = new Matrix4f();
    private static final Matrix4f VIEW = new Matrix4f();
    private static final Vector4f TMP = new Vector4f();
    private static final Quaternionf QUAT = new Quaternionf();

    public static Vec3d camPos = Vec3d.ZERO;
    public static boolean ready = false;
    public static int fbW, fbH;
    public static float sf = 1f;
    public static float td = 0f;
    public static float pxPerUnit = 1f;

    private Proj() {}

    public static void captureProjection(WorldRenderContext ctx) {
        PROJ.set(ctx.projectionMatrix());
        ready = true;
    }

    /** Call once per frame before anything else. Returns false if nothing can be drawn. */
    public static boolean begin(MinecraftClient mc, RenderTickCounter tc) {
        if (!ready || mc.world == null || mc.player == null) return false;
        Camera cam = mc.gameRenderer.getCamera();
        camPos = cam.getPos();
        VIEW.identity().rotation(cam.getRotation().conjugate(QUAT));
        td = tc.getTickDelta(true);
        Window win = mc.getWindow();
        fbW = win.getFramebufferWidth();
        fbH = win.getFramebufferHeight();
        sf = (float) win.getScaleFactor();
        pxPerUnit = fbH * 0.5f * PROJ.m11();
        return true;
    }

    public static void toClip(double x, double y, double z, float[] out) {
        TMP.set((float) (x - camPos.x), (float) (y - camPos.y), (float) (z - camPos.z), 1f);
        VIEW.transform(TMP);
        PROJ.transform(TMP);
        out[0] = TMP.x; out[1] = TMP.y; out[2] = TMP.z; out[3] = TMP.w;
    }

    /** out = {pixelX, pixelY, clipW}. False when the point is behind the camera. */
    public static boolean project(double x, double y, double z, float[] out) {
        TMP.set((float) (x - camPos.x), (float) (y - camPos.y), (float) (z - camPos.z), 1f);
        VIEW.transform(TMP);
        PROJ.transform(TMP);
        if (TMP.w <= E) return false;
        out[0] = (TMP.x / TMP.w * 0.5f + 0.5f) * fbW;
        out[1] = (1f - (TMP.y / TMP.w * 0.5f + 0.5f)) * fbH;
        out[2] = TMP.w;
        return true;
    }

    /** Clips a clip-space segment against the near plane and projects it to pixels (4 floats at o). */
    public static boolean clipEdge(float[] a, float[] b, float[] out, int o) {
        float ax = a[0], ay = a[1], aw = a[3], bx = b[0], by = b[1], bw = b[3];
        if (aw < E && bw < E) return false;
        if (aw < E) {
            float t = (E - aw) / (bw - aw);
            ax = ax + (bx - ax) * t;
            ay = ay + (by - ay) * t;
            aw = E;
        } else if (bw < E) {
            float t = (E - aw) / (bw - aw);
            bx = ax + (bx - ax) * t;
            by = ay + (by - ay) * t;
            bw = E;
        }
        out[o] = (ax / aw * 0.5f + 0.5f) * fbW;
        out[o + 1] = (1f - (ay / aw * 0.5f + 0.5f)) * fbH;
        out[o + 2] = (bx / bw * 0.5f + 0.5f) * fbW;
        out[o + 3] = (1f - (by / bw * 0.5f + 0.5f)) * fbH;
        return true;
    }

    /** True when a solid block lies between the camera and p. */
    public static boolean occluded(MinecraftClient mc, Vec3d p) {
        if (mc.world == null || mc.player == null) return false;
        try {
            var r = mc.world.raycast(new RaycastContext(camPos, p, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, mc.player));
            return r.getType() != HitResult.Type.MISS;
        } catch (Exception e) {
            return false;
        }
    }
}
