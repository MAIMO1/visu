package ru.pic.pic_visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class Config {
    public enum EspStyle {
        GLASS("Glass 3D"), WIRE("Wire 3D"), BOX("Box 2D"), CORNERS("Corners"), SKELETON("Skeleton");
        public final String label;
        EspStyle(String l) { label = l; }
        @Override public String toString() { return label; }
    }

    public enum ColorMode {
        STATIC("Static"), GRADIENT("Gradient"), RAINBOW("Rainbow"), HEALTH("Health");
        public final String label;
        ColorMode(String l) { label = l; }
        @Override public String toString() { return label; }
    }

    public enum PColor {
        THEME("Theme"), RAINBOW("Rainbow"), CUSTOM("Custom");
        public final String label;
        PColor(String l) { label = l; }
        @Override public String toString() { return label; }
    }

    /** Settings shared by every particle-like effect. */
    public static class PSet {
        public boolean enabled = false;
        public boolean star = true, circle = true, dollar = true, letterN = true, heart = false;
        public float count = 60f;
        public float radius = 14f;
        public float size = 1f;
        public float speed = 1f;
        public float life = 1f;
        public float gravity = 0f;
        public float spin = 1f;
        public float alpha = 1f;
        public boolean glow = true;
        public float glowAlpha = 0.35f;
        public boolean twinkle = true;
        public PColor colorMode = PColor.THEME;
        public int colorA = 0xFFB4B6FF;
        public int colorB = 0xFFFFFFFF;

        public int shapeMask() {
            int m = 0;
            if (star) m |= 1;
            if (circle) m |= 2;
            if (dollar) m |= 4;
            if (letterN) m |= 8;
            if (heart) m |= 16;
            return m;
        }
    }

    public int version = 3;
    public String lang = "en";
    public Map<String, Integer> binds = new HashMap<>();

    // Visuals
    public boolean espEnabled = true;
    public boolean showInvisible = true;
    public boolean showSelf = false;
    public boolean nametag = true;
    public boolean healthBar = true;
    public boolean tracers = false;
    public boolean showItem = false;

    public EspStyle espStyle = EspStyle.GLASS;
    public float espThickness = 2f;
    public float fillOpacity = 0.30f;
    public boolean espFill = true;
    public boolean espGlow = true;
    public boolean espOutline = true;
    public boolean skeletonHead = true;
    public boolean skeletonJoints = true;
    public boolean skeletonGaze = false;

    public boolean nameHealth = true;
    public boolean nameDistance = true;
    public boolean nameBg = true;
    public float nametagScale = 1f;

    // Effects
    public PSet world = new PSet();
    public boolean shootingStars = true;
    public boolean hideBehindBlocks = true;
    public PSet hit = new PSet();
    public boolean killBurst = true;
    public PSet trail = new PSet();
    public PSet jump = new PSet();
    public boolean targetHud = true;
    public float targetHudScale = 1f;

    // HUD
    public boolean hudWatermark = true;
    public boolean hudInfo = true;
    public float hudScale = 1f;

    // Theme
    public float maxDistance = 256f;
    public float animSpeed = 1f;
    public ColorMode colorMode = ColorMode.STATIC;
    public int colorA = 0xFFC8F7D4;
    public int colorB = 0xFFFFFFFF;
    public int invisibleColor = 0xFFFF8CC0;
    public boolean invisibleOwnColor = true;
    public int uiAccent = 0xFF8C8EF8;

    public Config() {
        world.enabled = true;
        world.count = 70f;
        world.radius = 14f;
        world.size = 1f;
        world.speed = 0.6f;

        hit.enabled = true;
        hit.count = 28f;
        hit.size = 1.1f;
        hit.speed = 1.2f;
        hit.gravity = 0.6f;
        hit.life = 1f;

        trail.enabled = false;
        trail.count = 40f;
        trail.size = 0.8f;
        trail.speed = 0.5f;
        trail.life = 0.9f;

        jump.enabled = true;
        jump.size = 1f;
        jump.life = 1f;
        jump.glow = true;
        jump.glowAlpha = 0.5f;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Config instance = new Config();

    public static Config get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pic_visuals.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null && c.version == 3) {
                    if (c.espStyle == null) c.espStyle = EspStyle.GLASS;
                    if (c.colorMode == null) c.colorMode = ColorMode.STATIC;
                    if (c.binds == null) c.binds = new HashMap<>();
                    if (c.lang == null) c.lang = "en";
                    if (c.world == null) c.world = new Config().world;
                    if (c.hit == null) c.hit = new Config().hit;
                    if (c.trail == null) c.trail = new Config().trail;
                    if (c.jump == null) c.jump = new Config().jump;
                    for (PSet s : new PSet[]{c.world, c.hit, c.trail, c.jump}) {
                        if (s.colorMode == null) s.colorMode = PColor.THEME;
                    }
                    instance = c;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception ignored) {
        }
    }

    public boolean ru() { return "ru".equals(lang); }
}
