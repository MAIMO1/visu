package ru.pic.pic_visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.pic.pic_visuals.Modules.Cat;
import ru.pic.pic_visuals.Modules.Mod;
import ru.pic.pic_visuals.Widgets.Row;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Main menu: sidebar with categories, search, and module cards with their settings inside. */
public class MenuScreen extends Screen {
    private static final int DW = 960, DH = 600, SIDEBAR = 218, GAP = 22;
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private static final class Card {
        Mod m;
        int x, y, w, h;
        final int[] bind = new int[4];
        final List<Row> rows = new ArrayList<>();
    }

    private final long openedAt = System.currentTimeMillis();
    private long lastNs = System.nanoTime();
    private float open = 0f;
    private Cat tab = Cat.VISUALS;
    private float tabSel = -1f;
    private float scroll = 0f, scrollT = 0f;
    private int contentH = 0;
    private Row dragging = null;
    private String query = "";
    private boolean searchFocus = false;
    private Mod listening = null;

    private float s = 1f, ox = 0f, oy = 0f, sf = 1f;
    private final int cx0 = SIDEBAR + 18, cx1 = DW - 26, cy0 = 84, cy1 = DH - 16;
    private final int[] searchRect = new int[4];
    private final int[] langRect = new int[4];
    private final List<Card> cards = new ArrayList<>();

    public MenuScreen() {
        super(Text.literal("Pic Visuals"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        Gfx.ga = 1f;
        Gfx.clearClip();
        Config.save();
    }

    // ------------------------------------------------------------------ helpers

    private double dx(double mx) { return (mx * sf - ox) / s; }
    private double dy(double my) { return (my * sf - oy) / s; }

    private boolean inContent(double x, double y) {
        return x >= cx0 - 4 && x < cx1 + 6 && y >= cy0 && y < cy1;
    }

    private static boolean in(double x, double y, int[] r) {
        return x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3];
    }

    private boolean matches(Mod m, String q) {
        if (m.name.toLowerCase(Locale.ROOT).contains(q)) return true;
        if (m.desc.en.toLowerCase(Locale.ROOT).contains(q) || m.desc.ru.toLowerCase(Locale.ROOT).contains(q)) return true;
        for (Row r : m.rows) {
            if (r.label.en.toLowerCase(Locale.ROOT).contains(q) || r.label.ru.toLowerCase(Locale.ROOT).contains(q)) return true;
        }
        return false;
    }

    private List<Mod> visibleMods() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return Modules.of(tab);
        List<Mod> out = new ArrayList<>();
        for (Mod m : Modules.all()) if (matches(m, q)) out.add(m);
        return out;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        Gfx.dt = dt;
        open += (1f - open) * (1f - (float) Math.exp(-dt * 12f));

        // Vanilla background blur (strength: Options > Video Settings > Menu Background Blur).
        this.renderBackground(ctx, mx, my, delta);

        Gfx.ga = open;
        try {
            Gfx.grad(ctx, 0, 0, width, height, 0x28000000, 0x60000000);
            Window win = client.getWindow();
            int fbW = win.getFramebufferWidth(), fbH = win.getFramebufferHeight();
            sf = (float) win.getScaleFactor();
            s = Math.max(0.5f, Math.min(fbW * 0.52f / DW, fbH * 0.82f / DH)) * (0.95f + 0.05f * open);
            ox = (fbW - DW * s) / 2f;
            oy = (fbH - DH * s) / 2f;

            MatrixStack ms = ctx.getMatrices();
            ms.push();
            ms.scale(1f / sf, 1f / sf, 1f);
            ms.translate(ox, oy, 0f);
            ms.scale(s, s, 1f);
            try {
                drawAll(ctx, (int) dx(mx), (int) dy(my));
            } finally {
                ms.pop();
            }
        } finally {
            Gfx.ga = 1f;
            Gfx.clearClip();
        }
    }

    private void drawAll(DrawContext ctx, int mx, int my) {
        Config c = Config.get();
        int a = Widgets.acc();

        for (int i = 5; i >= 1; i--) Gfx.rrect(ctx, -i * 5, -i * 5 + 8, DW + i * 10, DH + i * 10, 24 + i * 4, 0x0B000000);
        Gfx.rrect(ctx, 0, 0, DW, DH, 24, 0xF20E0F1A);
        Gfx.rrectRing(ctx, 0, 0, DW, DH, 24, 2, 0xFF1A1B30);

        drawSidebar(ctx, mx, my, a, c);
        drawHeader(ctx, mx, my, a, c);
        drawContent(ctx, mx, my, c);
    }

    private void drawSidebar(DrawContext ctx, int mx, int my, int a, Config c) {
        Icons.diamond(ctx, 48, 58, 10, 2.6f, a);
        Icons.diamond(ctx, 48, 58, 5, 2.2f, Colors.withAlpha(a, 0.6f));
        Gfx.textC(ctx, "pic visuals", 70, 58, 1.85f, a, false);

        Cat[] tabs = Cat.values();
        float target = 139 + tab.ordinal() * 45;
        if (tabSel < 0) tabSel = target;
        tabSel += (target - tabSel) * (1f - (float) Math.exp(-Gfx.dt * 18f));
        Gfx.rrect(ctx, 14, Math.round(tabSel) - 20, 190, 40, 11, Colors.withAlpha(a, 0.12f));

        for (int i = 0; i < tabs.length; i++) {
            int cy = 139 + i * 45;
            boolean hv = mx >= 14 && mx < 204 && my >= cy - 20 && my < cy + 20;
            float sel = Math.max(0f, 1f - Math.abs(tabSel - cy) / 45f);
            int col = Colors.lerp(hv ? 0xFFFFFFFF : 0xFFE0E0F0, a, sel);
            switch (tabs[i]) {
                case VISUALS -> Icons.eye(ctx, 40, cy, 9, col);
                case EFFECTS -> Icons.sparkle(ctx, 40, cy, 24, col);
                case HUD -> Icons.hud(ctx, 40, cy, 8, col);
                default -> Icons.theme(ctx, 40, cy, 8, col);
            }
            Gfx.textC(ctx, tabs[i].label.get(), 68, cy, 1.65f, col, false);
        }

        // user
        Gfx.circle(ctx, 32, 556, 15, 0xFFEDEDF6);
        Gfx.circle(ctx, 44, 568, 6, 0xFF0E0F1A);
        Gfx.circle(ctx, 44, 568, 4, 0xFF35D07F);
        Gfx.textC(ctx, client.getSession().getUsername(), 58, 549, 1.3f, 0xFFF0F0FA, false);
        Gfx.textC(ctx, LocalDate.now().format(DATE), 58, 565, 1.05f, a, false);
    }

    private void drawHeader(DrawContext ctx, int mx, int my, int a, Config c) {
        String title = query.trim().isEmpty() ? tab.label.get() : (c.ru() ? "Поиск" : "Search");
        Gfx.textC(ctx, title, cx0, 38, 1.9f, 0xFFF4F4FC, true);

        // search box
        int sx = DW - 26 - 196, sy = 18;
        searchRect[0] = sx; searchRect[1] = sy; searchRect[2] = 196; searchRect[3] = 40;
        Gfx.rrect(ctx, sx, sy, 196, 40, 12, 0xFF14152A);
        Gfx.rrectRing(ctx, sx, sy, 196, 40, 12, 2, searchFocus ? a : 0xFF1F2038);
        Icons.search(ctx, sx + 196 - 26, sy + 20, 8, 0xFF8283A6);
        if (query.isEmpty() && !searchFocus) {
            Gfx.textC(ctx, c.ru() ? "Поиск" : "Search", sx + 16, sy + 20, 1.35f, 0xFF7B7CA0, false);
        } else {
            String shown = Gfx.fit(query, 1.35f, false, 150);
            Gfx.textC(ctx, shown, sx + 16, sy + 20, 1.35f, 0xFFF0F0FA, false);
            if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0) {
                int cxp = sx + 16 + Math.round(Gfx.tw(shown, 1.35f, false)) + 2;
                Gfx.fill(ctx, cxp, sy + 11, cxp + 2, sy + 29, 0xFFF0F0FA);
            }
        }

        // language pill
        int lx = sx - 14 - 84, ly = 18;
        langRect[0] = lx; langRect[1] = ly; langRect[2] = 84; langRect[3] = 40;
        boolean hv = in(mx, my, langRect);
        if (hv) Gfx.rrect(ctx, lx, ly, 84, 40, 12, 0xFF14152A);
        Icons.globe(ctx, lx + 24, ly + 20, 8, 0xFFE0E0F0);
        Gfx.textC(ctx, c.ru() ? "RUS" : "ENG", lx + 42, ly + 20, 1.4f, 0xFFF0F0FA, false);
    }

    private void drawContent(DrawContext ctx, int mx, int my, Config c) {
        int viewH = cy1 - cy0;
        float maxScroll = Math.max(0, contentH - viewH);
        scrollT = Math.max(0f, Math.min(maxScroll, scrollT));
        scroll += (scrollT - scroll) * (1f - (float) Math.exp(-Gfx.dt * 16f));

        boolean hoverOk = inContent(mx, my);
        int hmx = hoverOk ? mx : -9999, hmy = hoverOk ? my : -9999;

        List<Mod> mods = visibleMods();
        cards.clear();
        int cw = (cx1 - cx0 - GAP) / 2;
        int[] colY = {0, 0};
        int startY = cy0 - Math.round(scroll);

        for (Mod m : mods) {
            Card cd = new Card();
            cd.m = m;
            if (m.enableRow != null) cd.rows.add(m.enableRow);
            if (m.expanded || m.enableRow == null) cd.rows.addAll(m.rows);
            int col = colY[0] <= colY[1] ? 0 : 1;
            cd.x = cx0 + col * (cw + GAP);
            cd.y = startY + colY[col];
            cd.w = cw;
            int h = 40 + 6;
            for (Row r : cd.rows) {
                r.x = cd.x;
                r.w = cw;
                h += r.height();
            }
            cd.h = h;
            colY[col] += h + 14;
            cards.add(cd);
        }
        contentH = Math.max(0, Math.max(colY[0], colY[1]) - 14);

        Gfx.setClip(cy0, cy1);
        for (Card cd : cards) {
            if (cd.y + cd.h < cy0 - 4 || cd.y > cy1 + 4) {
                // still need valid row positions for hit-testing; they are off-screen so just place them
                int ry = cd.y + 40;
                for (Row r : cd.rows) { r.y = ry; ry += r.height(); }
                continue;
            }
            drawCard(ctx, cd, hmx, hmy);
        }
        if (mods.isEmpty()) {
            Gfx.ctext(ctx, c.ru() ? "Ничего не найдено" : "Nothing found", (cx0 + cx1) / 2f, cy0 + 50, 1.6f, 0xFF6C6D8C, false);
        }
        Gfx.clearClip();

        if (contentH > viewH) {
            int bh = Math.max(36, viewH * viewH / contentH);
            int by = cy0 + Math.round((viewH - bh) * (scroll / Math.max(1f, contentH - viewH)));
            Gfx.rrect(ctx, DW - 16, by, 4, bh, 2, Colors.withAlpha(Widgets.acc(), 0.55f));
        }
    }

    private void drawCard(DrawContext ctx, Card cd, int mx, int my) {
        Mod m = cd.m;
        int x = cd.x, y = cd.y, w = cd.w, h = cd.h;
        int a = Widgets.acc();

        Gfx.rrect(ctx, x, y, w, h, 14, 0xFF10111F);
        Gfx.rrect(ctx, x, y, w, 40, 14, 0xFF15162A);
        Gfx.fill(ctx, x, y + 20, x + w, y + 40, 0xFF15162A);
        Gfx.rrectRing(ctx, x, y, w, h, 14, 2, 0xFF1B1C32);

        boolean on = !m.toggleable() || m.on.getAsBoolean();
        Icons.cube(ctx, x + 26, y + 20, 7, on ? a : 0xFF6C6D8C);
        Gfx.textC(ctx, m.name, x + 46, y + 20, 1.6f, 0xFFF2F2FC, true);

        if (m.toggleable()) {
            String bl = listening == m ? "..." : Modules.bindLabel(m);
            int bw = Math.round(Gfx.tw(bl, 1.3f, false));
            int bx = x + w - 18 - bw;
            Gfx.textC(ctx, bl, bx, y + 20, 1.3f, listening == m ? a : 0xFF7E7FA0, false);
            cd.bind[0] = bx - 10; cd.bind[1] = y; cd.bind[2] = bw + 20; cd.bind[3] = 40;
        } else {
            cd.bind[2] = 0;
        }

        int ry = y + 40;
        for (Row r : cd.rows) {
            r.x = x;
            r.y = ry;
            r.w = w;
            r.render(ctx, mx, my);
            ry += r.height();
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mxRaw, double myRaw, int btn) {
        double mx = dx(mxRaw), my = dy(myRaw);
        Config c = Config.get();
        listeningCancelIfClickedElsewhere(mx, my);

        if (in(mx, my, searchRect)) { searchFocus = true; return true; }
        searchFocus = false;

        if (in(mx, my, langRect)) {
            c.lang = c.ru() ? "en" : "ru";
            return true;
        }

        Cat[] tabs = Cat.values();
        for (int i = 0; i < tabs.length; i++) {
            int cy = 139 + i * 45;
            if (mx >= 14 && mx < 204 && my >= cy - 20 && my < cy + 20) {
                if (tab != tabs[i] || !query.isEmpty()) {
                    tab = tabs[i];
                    query = "";
                    scroll = 0; scrollT = 0;
                }
                return true;
            }
        }

        if (inContent(mx, my)) {
            for (Card cd : cards) {
                if (cd.bind[2] > 0 && in(mx, my, cd.bind) && my >= cy0 && btn == 0) {
                    listening = cd.m;
                    return true;
                }
                for (Row r : cd.rows) {
                    if (my >= cy0 && my < cy1 && r.hover(mx, my) && r.click(mx, my, btn)) {
                        dragging = r;
                        return true;
                    }
                }
            }
        }
        return super.mouseClicked(mxRaw, myRaw, btn);
    }

    private void listeningCancelIfClickedElsewhere(double mx, double my) {
        if (listening == null) return;
        for (Card cd : cards) {
            if (cd.m == listening && cd.bind[2] > 0 && in(mx, my, cd.bind)) return;
        }
        listening = null;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double ddx, double ddy) {
        if (dragging != null) {
            dragging.drag(dx(mx), dy(my));
            return true;
        }
        return super.mouseDragged(mx, my, btn, ddx, ddy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (dragging != null) {
            dragging.release();
            dragging = null;
        }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (inContent(dx(mx), dy(my))) {
            scrollT -= (float) vertical * 60f;
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchFocus && chr >= 32 && chr != 127 && query.length() < 24) {
            query += chr;
            scroll = 0; scrollT = 0;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            Config c = Config.get();
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                listening = null;
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                c.binds.remove(listening.name);
                listening = null;
            } else {
                c.binds.put(listening.name, keyCode);
                listening = null;
            }
            return true;
        }
        if (searchFocus) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocus = false;
                return true;
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_H && System.currentTimeMillis() - openedAt > 300) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
