package ru.pic.pic_visuals;

/** A string in two languages. */
public final class L {
    public final String en, ru;

    private L(String en, String ru) {
        this.en = en;
        this.ru = ru;
    }

    public static L of(String en, String ru) { return new L(en, ru); }

    public static final L EMPTY = new L("", "");

    public String get() { return Config.get().ru() ? ru : en; }
}
