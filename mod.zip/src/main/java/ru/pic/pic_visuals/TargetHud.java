package ru.pic.pic_visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/** Small panel with the target's face, name and health (bottom centre). */
public final class TargetHud {
    private static LivingEntity shown;
    private static float anim = 0f;
    private static float hpShown = 0f;

    private TargetHud() {}

    public static void render(DrawContext ctx, MinecraftClient mc, float dt) {
        Config c = Config.get();
        if (!c.targetHud || mc.player == null || mc.world == null || mc.options.hudHidden) {
            anim = 0f;
            shown = null;
            return;
        }
        LivingEntity t = null;
        long age = System.currentTimeMillis() - Effects.lastHitMs;
        if (Effects.lastHit instanceof LivingEntity le && le.isAlive() && age < 6000L) {
            t = le;
        } else {
            Entity te = mc.targetedEntity;
            if (te instanceof LivingEntity le2 && le2.isAlive()) t = le2;
        }
        if (t != null) shown = t;
        anim += ((t != null ? 1f : 0f) - anim) * Math.min(1f, dt * 10f);
        if (anim < 0.02f) {
            if (t == null) shown = null;
            return;
        }
        if (shown == null) return;

        float hp = shown.getHealth() + shown.getAbsorptionAmount();
        float max = Math.max(1f, shown.getMaxHealth());
        hpShown += (hp - hpShown) * Math.min(1f, dt * 8f);
        if (Math.abs(hpShown - hp) > max) hpShown = hp;

        int fbW = Proj.fbW, fbH = Proj.fbH;
        float u = fbH / 1080f * c.targetHudScale;
        int acc = c.uiAccent | 0xFF000000;

        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.scale(1f / Proj.sf, 1f / Proj.sf, 1f);
        Gfx.ga = anim;
        try {
            int pw = Math.round(310 * u), ph = Math.round(92 * u);
            int x = (fbW - pw) / 2;
            int y = fbH - Math.round(200 * u) - ph + Math.round((1f - anim) * 16 * u);
            int r = Math.round(20 * u);
            Gfx.rrect(ctx, x, y, pw, ph, r, 0xD00D0E1A);
            Gfx.rrectRing(ctx, x, y, pw, ph, r, Math.max(1, Math.round(u * 1.2f)), 0xFF22233C);

            int fs = Math.round(62 * u);
            int fx = x + Math.round(15 * u), fy = y + (ph - fs) / 2;
            if (shown instanceof AbstractClientPlayerEntity pl) {
                PlayerSkinDrawer.draw(ctx, pl.getSkinTextures(), fx, fy, fs);
            } else {
                Gfx.rrect(ctx, fx, fy, fs, fs, Math.round(10 * u), 0xFF1D1E33);
                String n = shown.getName().getString();
                String ini = n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(Locale.ROOT);
                Gfx.ctext(ctx, ini, fx + fs / 2f, fy + fs / 2f - Gfx.CAP * 3f * u / 2f, 3f * u, 0xFFE8E8F6, true);
            }

            int tx = fx + fs + Math.round(16 * u);
            int tw = x + pw - Math.round(16 * u) - tx;
            String name = Gfx.fit(shown.getName().getString(), 1.75f * u, true, tw);
            Gfx.text(ctx, name, tx, y + Math.round(14 * u), 1.75f * u, 0xFFF2F2FC, true);

            int bh = Math.round(24 * u), by = y + ph - Math.round(16 * u) - bh;
            Gfx.rrect(ctx, tx, by, tw, bh, bh / 2, 0xFF1A1B30);
            float ratio = MathHelper.clamp(hpShown / max, 0f, 1f);
            int fw = Math.max(bh, Math.round(tw * ratio));
            Gfx.rrect(ctx, tx, by, fw, bh, bh / 2, acc);
            Gfx.hgrad(ctx, tx + bh / 2, by, Math.max(0, fw - bh), bh, acc, Colors.lerp(acc, 0xFFFFFFFF, 0.35f));
            Gfx.ctext(ctx, String.format(Locale.ROOT, "%.1f", hpShown), tx + tw / 2f,
                    by + bh / 2f - Gfx.CAP * 1.4f * u / 2f, 1.4f * u, 0xFFFFFFFF, true);
        } finally {
            Gfx.ga = 1f;
            ms.pop();
        }
    }
}
