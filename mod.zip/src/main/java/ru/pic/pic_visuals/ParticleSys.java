package ru.pic.pic_visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Custom (non-vanilla) particles: stars, circles, dollar signs, the letter N and hearts.
 * They live in world space and are projected to the screen every frame.
 */
public final class ParticleSys {
    private static final int MAX = 1600;
    private static final int HIST = 14;
    private static final Random RNG = new Random();

    private static final class P {
        double x, y, z;
        float vx, vy, vz;
        float age, life, size, rot, spin, gravity, drag, alpha;
        int shape, color;
        boolean glow, twinkle, world, hide, shooting;
        float glowA, phase, vis = 1f;
        boolean occl;
        int id;
        final double[] hist = new double[HIST * 3];
        int histN;
        float histTimer;
    }

    private static final class Ring {
        double x, y, z;
        float age, life, maxR, alpha;
        int colA, colB;
        boolean glow;
        float glowA;
    }

    private static final List<P> LIST = new ArrayList<>();
    private static final List<Ring> RINGS = new ArrayList<>();
    private static int idCounter = 0;
    private static int frame = 0;
    private static final float[] OUT = new float[3];
    private static final float[][] RC = new float[48][4];
    private static final float[] SEG = new float[4];

    private ParticleSys() {}

    public static int worldAlive() {
        int n = 0;
        for (P p : LIST) if (p.world) n++;
        return n;
    }

    public static void clear() {
        LIST.clear();
        RINGS.clear();
    }

    // ------------------------------------------------------------------ helpers

    private static float rnd() { return RNG.nextFloat(); }
    private static float rnd(float a, float b) { return a + (b - a) * RNG.nextFloat(); }

    private static int pickShape(Config.PSet s) {
        int mask = s.shapeMask();
        if (mask == 0) return -1;
        for (int i = 0; i < 12; i++) {
            int sh = RNG.nextInt(5);
            if ((mask & (1 << sh)) != 0) return sh;
        }
        for (int sh = 0; sh < 5; sh++) if ((mask & (1 << sh)) != 0) return sh;
        return -1;
    }

    private static int pickColor(Config c, Config.PSet s) {
        return switch (s.colorMode) {
            case THEME -> Colors.lerp(c.colorA | 0xFF000000, c.colorB | 0xFF000000, rnd());
            case RAINBOW -> Colors.hsv(rnd(), 0.55f, 1f);
            case CUSTOM -> Colors.lerp(s.colorA | 0xFF000000, s.colorB | 0xFF000000, rnd());
        };
    }

    private static P base(Config c, Config.PSet s, int shape) {
        P p = new P();
        p.id = idCounter++;
        p.shape = shape;
        p.color = pickColor(c, s);
        p.alpha = s.alpha;
        p.glow = s.glow;
        p.glowA = s.glowAlpha;
        p.twinkle = s.twinkle;
        p.phase = rnd() * 6.28f;
        p.rot = rnd() * 6.28f;
        p.spin = rnd(-1.6f, 1.6f) * s.spin;
        p.drag = 1.2f;
        return p;
    }

    private static void add(P p) {
        if (LIST.size() >= MAX) LIST.remove(0);
        LIST.add(p);
    }

    // ------------------------------------------------------------------ spawners

    public static void spawnWorld(Config c, MinecraftClient mc, int n) {
        Config.PSet s = c.world;
        if (mc.player == null) return;
        for (int i = 0; i < n; i++) {
            int shape = pickShape(s);
            if (shape < 0) return;
            P p = base(c, s, shape);
            double ang = rnd() * Math.PI * 2;
            double rad = Math.sqrt(rnd()) * s.radius;
            Vec3d eye = mc.player.getEyePos();
            p.x = eye.x + Math.cos(ang) * rad;
            p.z = eye.z + Math.sin(ang) * rad;
            p.y = eye.y + rnd(-2.2f, Math.max(3f, s.radius * 0.55f));
            float sp = 0.25f * s.speed;
            p.vx = rnd(-sp, sp);
            p.vy = rnd(-sp * 0.5f, sp);
            p.vz = rnd(-sp, sp);
            p.life = rnd(4f, 8f) * s.life;
            p.size = 0.16f * s.size * rnd(0.6f, 1.4f);
            p.drag = 0.3f;
            p.world = true;
            p.hide = c.hideBehindBlocks;
            add(p);
        }
    }

    public static void burst(Config c, Config.PSet s, Vec3d pos, int n, float speedMul, float sizeMul) {
        for (int i = 0; i < n; i++) {
            int shape = pickShape(s);
            if (shape < 0) return;
            P p = base(c, s, shape);
            float z = rnd(-1f, 1f);
            float a = rnd() * 6.2832f;
            float r = (float) Math.sqrt(1f - z * z);
            float sp = rnd(1.4f, 3.8f) * s.speed * speedMul;
            p.x = pos.x; p.y = pos.y; p.z = pos.z;
            p.vx = r * (float) Math.cos(a) * sp;
            p.vy = (z * 0.8f + 0.3f) * sp;
            p.vz = r * (float) Math.sin(a) * sp;
            p.life = rnd(0.7f, 1.5f) * s.life;
            p.size = 0.14f * s.size * sizeMul * rnd(0.7f, 1.3f);
            p.gravity = 3.2f * s.gravity;
            p.drag = 2.0f;
            add(p);
        }
    }

    public static void trailSpawn(Config c, Vec3d pos) {
        Config.PSet s = c.trail;
        int shape = pickShape(s);
        if (shape < 0) return;
        P p = base(c, s, shape);
        p.x = pos.x + rnd(-0.28f, 0.28f);
        p.y = pos.y + rnd(0.05f, 0.9f);
        p.z = pos.z + rnd(-0.28f, 0.28f);
        float sp = 0.5f * s.speed;
        p.vx = rnd(-sp, sp);
        p.vy = rnd(0.1f, 0.6f) * s.speed;
        p.vz = rnd(-sp, sp);
        p.life = rnd(0.45f, 0.95f) * s.life;
        p.size = 0.12f * s.size * rnd(0.7f, 1.3f);
        p.gravity = 1.5f * s.gravity;
        add(p);
    }

    public static void shootingStar(Config c, MinecraftClient mc) {
        Config.PSet s = c.world;
        P p = base(c, s, Gfx.SHAPE_STAR);
        p.shooting = true;
        p.glow = true;
        p.glowA = Math.max(0.4f, s.glowAlpha);
        p.twinkle = false;
        double ang = rnd() * Math.PI * 2;
        double dist = rnd(26f, 46f);
        Vec3d eye = mc.player.getEyePos();
        p.x = eye.x + Math.cos(ang) * dist;
        p.z = eye.z + Math.sin(ang) * dist;
        p.y = eye.y + rnd(14f, 30f);
        double tang = ang + (RNG.nextBoolean() ? 1 : -1) * Math.PI / 2;
        float sp = rnd(20f, 34f);
        p.vx = (float) Math.cos(tang) * sp;
        p.vz = (float) Math.sin(tang) * sp;
        p.vy = -rnd(4f, 12f);
        p.life = rnd(1.0f, 1.6f);
        p.size = 1.15f * s.size;
        p.drag = 0f;
        p.spin = 1.5f;
        add(p);
    }

    public static void ring(Config c, Vec3d pos) {
        Config.PSet s = c.jump;
        Ring r = new Ring();
        r.x = pos.x; r.y = pos.y + 0.03; r.z = pos.z;
        r.life = Math.max(0.3f, 0.9f * s.life);
        r.maxR = 2.2f * s.size;
        r.alpha = s.alpha;
        r.glow = s.glow;
        r.glowA = s.glowAlpha;
        switch (s.colorMode) {
            case THEME -> { r.colA = c.colorA | 0xFF000000; r.colB = c.colorB | 0xFF000000; }
            case RAINBOW -> {
                float h = rnd();
                r.colA = Colors.hsv(h, 0.6f, 1f);
                r.colB = Colors.hsv(h + 0.3f, 0.6f, 1f);
            }
            case CUSTOM -> { r.colA = s.colorA | 0xFF000000; r.colB = s.colorB | 0xFF000000; }
        }
        RINGS.add(r);
        if (RINGS.size() > 24) RINGS.remove(0);
    }

    // ------------------------------------------------------------------ update

    public static void update(float dt) {
        Iterator<P> it = LIST.iterator();
        while (it.hasNext()) {
            P p = it.next();
            p.age += dt;
            if (p.age >= p.life) { it.remove(); continue; }
            float damp = (float) Math.exp(-p.drag * dt);
            p.vx *= damp; p.vz *= damp;
            p.vy = p.vy * damp - p.gravity * dt;
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            p.rot += p.spin * dt;
            if (p.shooting) {
                p.histTimer += dt;
                if (p.histTimer > 0.022f) {
                    p.histTimer = 0f;
                    int n = Math.min(p.histN, HIST - 1);
                    for (int i = n; i > 0; i--) {
                        p.hist[i * 3] = p.hist[(i - 1) * 3];
                        p.hist[i * 3 + 1] = p.hist[(i - 1) * 3 + 1];
                        p.hist[i * 3 + 2] = p.hist[(i - 1) * 3 + 2];
                    }
                    p.hist[0] = p.x; p.hist[1] = p.y; p.hist[2] = p.z;
                    p.histN = Math.min(HIST, p.histN + 1);
                }
            }
        }
        Iterator<Ring> rit = RINGS.iterator();
        while (rit.hasNext()) {
            Ring r = rit.next();
            r.age += dt;
            if (r.age >= r.life) rit.remove();
        }
    }

    // ------------------------------------------------------------------ render

    public static void render(DrawContext ctx, MinecraftClient mc, float dt) {
        if (LIST.isEmpty() && RINGS.isEmpty()) return;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.scale(1f / Proj.sf, 1f / Proj.sf, 1f);
        try {
            renderAll(ctx, mc, dt);
        } finally {
            ms.pop();
        }
    }

    private static void renderAll(DrawContext ctx, MinecraftClient mc, float dt) {
        frame++;
        int rayBudget = 26;
        float time = Colors.time();
        float u = Proj.fbH / 1080f;

        for (Ring r : RINGS) drawRing(ctx, r, time, u);

        for (P p : LIST) {
            if (!Proj.project(p.x, p.y, p.z, OUT)) continue;
            float sx = OUT[0], sy = OUT[1], w = OUT[2];
            if (sx < -120 || sx > Proj.fbW + 120 || sy < -120 || sy > Proj.fbH + 120) continue;

            if (p.hide && rayBudget > 0 && (frame + p.id) % 5 == 0) {
                rayBudget--;
                p.occl = Proj.occluded(mc, new Vec3d(p.x, p.y, p.z));
            }
            float vt = p.occl ? 0f : 1f;
            p.vis += (vt - p.vis) * Math.min(1f, dt * 9f);
            if (p.vis < 0.02f) continue;

            float f = Math.min(1f, Math.min(p.age / (0.12f * p.life), (p.life - p.age) / (0.35f * p.life)));
            float a = p.alpha * f * p.vis;
            if (p.twinkle) a *= 0.72f + 0.28f * (float) Math.sin(time * 5f + p.phase);
            float sizePx = Math.max(3f, Math.min(260f, p.size * Proj.pxPerUnit / w));
            int col = Colors.mulAlpha(p.color | 0xFF000000, a);

            if (p.shooting && p.histN > 1) drawStarTrail(ctx, p, a, sizePx);

            if (p.glow) {
                Gfx.sprite(ctx, Gfx.TEX_GLOW, sx, sy, sizePx * 3.2f, 0f, Colors.mulAlpha(p.color | 0xFF000000, a * p.glowA * 1.6f));
            }
            Gfx.sprite(ctx, Gfx.shapeTex(p.shape), sx, sy, sizePx, p.rot, col);
        }
    }

    private static void drawStarTrail(DrawContext ctx, P p, float a, float sizePx) {
        float px = 0, py = 0;
        boolean have = false;
        float[] o = new float[3];
        if (Proj.project(p.x, p.y, p.z, o)) { px = o[0]; py = o[1]; have = true; }
        int base = p.color | 0xFF000000;
        for (int i = 0; i < p.histN; i++) {
            if (!Proj.project(p.hist[i * 3], p.hist[i * 3 + 1], p.hist[i * 3 + 2], o)) { have = false; continue; }
            float t = i / (float) p.histN;
            if (have) {
                float th = Math.max(1f, sizePx * 0.30f * (1f - t));
                int col = Colors.mulAlpha(base, a * (1f - t) * 0.85f);
                Gfx.lineF(ctx, px, py, o[0], o[1], th * 2.4f, Colors.mulAlpha(col, 0.25f));
                Gfx.lineF(ctx, px, py, o[0], o[1], th, col);
            }
            px = o[0]; py = o[1]; have = true;
        }
    }

    private static void drawRing(DrawContext ctx, Ring r, float time, float u) {
        float t = r.age / r.life;
        float ease = 1f - (1f - t) * (1f - t) * (1f - t);
        float R = Math.max(0.05f, r.maxR * ease);
        float a = (float) Math.pow(1f - t, 1.35) * r.alpha;
        if (a < 0.01f) return;
        float th = 2.6f * u;
        for (int pass = 0; pass < 2; pass++) {
            float rad = pass == 0 ? R : R * 0.72f;
            float pa = pass == 0 ? a : a * 0.5f;
            int n = 44;
            for (int i = 0; i < n; i++) {
                double ang = i * Math.PI * 2 / n;
                Proj.toClip(r.x + Math.cos(ang) * rad, r.y, r.z + Math.sin(ang) * rad, RC[i]);
            }
            for (int i = 0; i < n; i++) {
                if (!Proj.clipEdge(RC[i], RC[(i + 1) % n], SEG, 0)) continue;
                int col = Colors.wave(r.colA, r.colB, i / (float) n + time * 0.25f);
                int hot = Colors.lerp(col, 0xFFFFFFFF, 0.45f);
                if (r.glow) {
                    Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th * 4.2f, Colors.mulAlpha(col, pa * 0.10f * r.glowA * 2f));
                    Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th * 2.2f, Colors.mulAlpha(col, pa * 0.22f * r.glowA * 2f));
                }
                Gfx.lineF(ctx, SEG[0], SEG[1], SEG[2], SEG[3], th, Colors.mulAlpha(hot, pa));
            }
        }
    }
}
