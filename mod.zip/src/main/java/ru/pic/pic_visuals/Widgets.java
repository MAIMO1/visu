package ru.pic.pic_visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Setting rows shown inside module cards (design-space pixels). */
public final class Widgets {
    private Widgets() {}

    static final int PAD = 18;
    static final float KL = 1.5f;   // label scale
    static final float KD = 1.15f;  // description scale

    static int acc() { return Config.get().uiAccent | 0xFF000000; }

    static float approach(float cur, float target) {
        return cur + (target - cur) * (1f - (float) Math.exp(-Gfx.dt * 16f));
    }

    public abstract static class Row {
        public int x, y, w;
        final L label, desc;
        private List<String> cache;
        private int cacheW = -1;
        private boolean cacheRu;

        Row(L label, L desc) {
            this.label = label;
            this.desc = desc == null ? L.EMPTY : desc;
        }

        protected abstract int rightW();

        protected int leftW() { return Math.max(40, w - PAD - rightW() - 14 - PAD / 2); }

        protected List<String> lines() {
            boolean ru = Config.get().ru();
            int lw = leftW();
            if (cache == null || cacheW != lw || cacheRu != ru) {
                cache = new ArrayList<>();
                String d = desc.get();
                if (!d.isEmpty()) {
                    String line = "";
                    for (String word : d.split(" ")) {
                        String t = line.isEmpty() ? word : line + " " + word;
                        if (Gfx.tw(t, KD, false) > lw && !line.isEmpty()) {
                            cache.add(line);
                            line = word;
                        } else {
                            line = t;
                        }
                    }
                    if (!line.isEmpty()) cache.add(line);
                }
                cacheW = lw;
                cacheRu = ru;
            }
            return cache;
        }

        public int height() {
            return Math.max(44, 11 + 18 + lines().size() * 15 + 11);
        }

        /** Vertical centre of the control (aligned with the label line). */
        protected int cy() { return y + 20; }

        public final void render(DrawContext ctx, int mx, int my) {
            Gfx.text(ctx, Gfx.fit(label.get(), KL, false, leftW()), x + PAD, y + 11, KL, 0xFFEDEDF8, false);
            List<String> ls = lines();
            for (int i = 0; i < ls.size(); i++) {
                Gfx.text(ctx, ls.get(i), x + PAD, y + 11 + 18 + i * 15, KD, 0xFF6C6D8C, false);
            }
            drawControl(ctx, mx, my);
        }

        protected abstract void drawControl(DrawContext ctx, int mx, int my);

        public boolean click(double mx, double my, int btn) { return false; }
        public void drag(double mx, double my) { }
        public void release() { }

        public boolean hover(double mx, double my) {
            return mx >= x && mx < x + w && my >= y && my < y + height();
        }
    }

    // ------------------------------------------------------------------ checkbox

    public static class ToggleRow extends Row {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;
        private final Runnable gear;
        private float anim = -1f;

        public ToggleRow(L label, L desc, BooleanSupplier get, Consumer<Boolean> set, Runnable gear) {
            super(label, desc);
            this.get = get;
            this.set = set;
            this.gear = gear;
        }

        @Override protected int rightW() { return gear != null ? 22 + 14 + 18 : 22; }

        private int bx() { return x + w - PAD - 22; }
        private int gx() { return bx() - 14 - 9; }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            float target = get.getAsBoolean() ? 1f : 0f;
            if (anim < 0) anim = target;
            anim = approach(anim, target);
            int a = acc();
            int bx = bx(), by = cy() - 11;
            Gfx.rrect(ctx, bx, by, 22, 22, 6, Colors.lerp(0xFF151628, a, anim));
            Gfx.rrectRing(ctx, bx, by, 22, 22, 6, 2, Colors.lerp(0xFF2A2B48, a, anim));
            if (anim > 0.05f) Icons.check(ctx, bx + 2, by + 2, 18, Colors.mulAlpha(0xFFFFFFFF, anim));
            if (gear != null) {
                boolean hv = Math.abs(mx - gx()) < 12 && Math.abs(my - cy()) < 12;
                Icons.gear(ctx, gx(), cy(), 9, hv ? 0xFFFFFFFF : 0xFF8283A6);
            }
        }

        @Override public boolean click(double mx, double my, int btn) {
            if (gear != null && Math.abs(mx - gx()) < 13 && Math.abs(my - cy()) < 13) {
                gear.run();
                return true;
            }
            if (btn != 0) return false;
            set.accept(!get.getAsBoolean());
            return true;
        }
    }

    // ------------------------------------------------------------------ slider

    public static class SliderRow extends Row {
        private final String fmt;
        private final float min, max, step;
        private final Supplier<Float> get;
        private final Consumer<Float> set;
        private float shown = Float.NaN;
        private boolean dragging;
        private final int valW;
        private static final int TRACK = 84;

        public SliderRow(L label, L desc, float min, float max, float step, String fmt, Supplier<Float> get, Consumer<Float> set) {
            super(label, desc);
            this.min = min; this.max = max; this.step = step; this.fmt = fmt; this.get = get; this.set = set;
            this.valW = Math.round(Math.max(
                    Gfx.tw(String.format(Locale.ROOT, fmt, min), 1.3f, false),
                    Gfx.tw(String.format(Locale.ROOT, fmt, max), 1.3f, false))) + 2;
        }

        @Override protected int rightW() { return TRACK + 10 + valW; }

        private int trX() { return x + w - PAD - valW - 10 - TRACK; }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            float v = get.get();
            float frac = MathHelper.clamp((v - min) / (max - min), 0f, 1f);
            if (Float.isNaN(shown)) shown = frac;
            shown = approach(shown, frac);
            String vs = String.format(Locale.ROOT, fmt, v);
            Gfx.textC(ctx, vs, x + w - PAD - Gfx.tw(vs, 1.3f, false), cy(), 1.3f, 0xFFEDEDF8, false);
            int a = acc();
            int tx = trX(), ty = cy() - 2;
            Gfx.rrect(ctx, tx, ty, TRACK, 4, 2, 0xFF25263F);
            int fw = Math.max(4, Math.round(TRACK * shown));
            Gfx.rrect(ctx, tx, ty, fw, 4, 2, a);
            Gfx.circle(ctx, tx + fw, ty + 2, 7, 0xFF0E0F1A);
            Gfx.circle(ctx, tx + fw, ty + 2, 5, a);
            Gfx.circle(ctx, tx + fw, ty + 2, 2, 0xFFFFFFFF);
        }

        private void update(double mx) {
            float f = MathHelper.clamp((float) ((mx - trX()) / TRACK), 0f, 1f);
            float v = min + f * (max - min);
            v = Math.round(v / step) * step;
            set.accept(MathHelper.clamp(v, min, max));
        }

        @Override public boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            if (mx < trX() - 10) return false;
            dragging = true;
            update(mx);
            return true;
        }
        @Override public void drag(double mx, double my) { if (dragging) update(mx); }
        @Override public void release() { dragging = false; }
    }

    // ------------------------------------------------------------------ enum picker

    public static class EnumRow<E extends Enum<E>> extends Row {
        private final E[] vals;
        private final Supplier<E> get;
        private final Consumer<E> set;
        private final int boxW;

        public EnumRow(L label, L desc, E[] vals, Supplier<E> get, Consumer<E> set) {
            super(label, desc);
            this.vals = vals; this.get = get; this.set = set;
            float m = 0;
            for (E v : vals) m = Math.max(m, Gfx.tw(v.toString(), 1.25f, false));
            this.boxW = Math.min(150, Math.round(m) + 24);
        }

        @Override protected int rightW() { return boxW; }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            int bx = x + w - PAD - boxW, by = cy() - 11;
            boolean hv = hover(mx, my);
            Gfx.rrect(ctx, bx, by, boxW, 22, 7, hv ? 0xFF1A1B33 : 0xFF151628);
            Gfx.rrectRing(ctx, bx, by, boxW, 22, 7, 2, 0xFF2A2B48);
            Gfx.ctext(ctx, Gfx.fit(get.get().toString(), 1.25f, false, boxW - 10), bx + boxW / 2f, cy() - Gfx.CAP * 1.25f / 2f, 1.25f, 0xFFD8D8EC, false);
        }

        @Override public boolean click(double mx, double my, int btn) {
            int i = get.get().ordinal();
            if (btn == 0) i = (i + 1) % vals.length;
            else if (btn == 1) i = (i + vals.length - 1) % vals.length;
            else return false;
            set.accept(vals[i]);
            return true;
        }
    }

    // ------------------------------------------------------------------ shape chips

    public static class ChipsRow extends Row {
        private final int[] shapes;
        private final List<BooleanSupplier> gets;
        private final List<Consumer<Boolean>> sets;
        private static final int CH = 24, GAP = 5;

        public ChipsRow(L label, L desc, int[] shapes, List<BooleanSupplier> gets, List<Consumer<Boolean>> sets) {
            super(label, desc);
            this.shapes = shapes; this.gets = gets; this.sets = sets;
        }

        @Override protected int rightW() { return shapes.length * CH + (shapes.length - 1) * GAP; }

        private int cx0() { return x + w - PAD - rightW(); }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            int a = acc();
            for (int i = 0; i < shapes.length; i++) {
                int bx = cx0() + i * (CH + GAP), by = cy() - CH / 2;
                boolean on = gets.get(i).getAsBoolean();
                Gfx.rrect(ctx, bx, by, CH, CH, 7, on ? Colors.withAlpha(a, 0.25f) : 0xFF151628);
                Gfx.rrectRing(ctx, bx, by, CH, CH, 7, 2, on ? a : 0xFF2A2B48);
                Gfx.sprite(ctx, Gfx.shapeTex(shapes[i]), bx + CH / 2f, by + CH / 2f, 15, 0f, on ? 0xFFFFFFFF : 0xFF5D5E7E);
            }
        }

        @Override public boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            for (int i = 0; i < shapes.length; i++) {
                int bx = cx0() + i * (CH + GAP);
                if (mx >= bx && mx < bx + CH) {
                    sets.get(i).accept(!gets.get(i).getAsBoolean());
                    return true;
                }
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ colour picker

    public static class ColorRow extends Row {
        private final IntSupplier get;
        private final IntConsumer set;
        private boolean expanded;
        private float exp;
        private final float[] hsb = new float[3];
        private int lastSet;
        private int drag = -1;

        public ColorRow(L label, L desc, IntSupplier get, IntConsumer set) {
            super(label, desc);
            this.get = get; this.set = set;
            lastSet = get.getAsInt() | 0xFF000000;
            Colors.toHsb(lastSet, hsb);
        }

        @Override protected int rightW() { return 40; }

        private int baseH() { return super.height(); }

        @Override public int height() { return baseH() + Math.round(68 * exp); }

        private int sx() { return x + PAD; }
        private int sw() { return w - PAD * 2; }
        private int stripY(int i) { return y + baseH() + 2 + i * 21; }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            int cur = get.getAsInt() | 0xFF000000;
            if (drag < 0 && cur != lastSet) { Colors.toHsb(cur, hsb); lastSet = cur; }
            exp = approach(exp, expanded ? 1f : 0f);
            if (Math.abs(exp - (expanded ? 1f : 0f)) < 0.01f) exp = expanded ? 1f : 0f;

            int bx = x + w - PAD - 40, by = cy() - 11;
            Gfx.rrect(ctx, bx, by, 40, 22, 7, 0xFF2A2B48);
            Gfx.rrect(ctx, bx + 2, by + 2, 36, 18, 5, cur);

            if (exp > 0.05f) {
                float old = Gfx.ga;
                Gfx.ga = old * exp;
                for (int i = 0; i < 3; i++) {
                    int sy = stripY(i);
                    Gfx.rrect(ctx, sx() - 1, sy - 1, sw() + 2, 16, 5, 0xFF000000);
                    for (int px = 4; px < sw() - 4; px += 3) {
                        float f = px / (float) Math.max(1, sw() - 1);
                        int col = switch (i) {
                            case 0 -> Colors.hsv(f, 1f, 1f);
                            case 1 -> Colors.hsv(hsb[0], f, 1f);
                            default -> Colors.hsv(hsb[0], hsb[1], f);
                        };
                        Gfx.fill(ctx, sx() + px, sy, Math.min(sx() + px + 3, sx() + sw() - 4), sy + 14, col);
                    }
                    int kx = sx() + 4 + Math.round(hsb[i] * (sw() - 9));
                    Gfx.rrect(ctx, kx - 3, sy - 3, 6, 20, 3, 0xFF000000);
                    Gfx.rrect(ctx, kx - 2, sy - 2, 4, 18, 2, 0xFFFFFFFF);
                }
                Gfx.ga = old;
            }
        }

        private void update(double mx) {
            float f = MathHelper.clamp((float) ((mx - sx() - 4) / (sw() - 9)), 0f, 1f);
            hsb[drag] = f;
            int c = Colors.hsv(hsb[0], hsb[1], hsb[2]);
            set.accept(c);
            lastSet = c | 0xFF000000;
        }

        @Override public boolean click(double mx, double my, int btn) {
            if (btn != 0) return false;
            if (my < y + baseH()) { expanded = !expanded; return true; }
            if (expanded) {
                for (int i = 0; i < 3; i++) {
                    int sy = stripY(i);
                    if (my >= sy - 4 && my < sy + 18) { drag = i; update(mx); return true; }
                }
            }
            return false;
        }
        @Override public void drag(double mx, double my) { if (drag >= 0) update(mx); }
        @Override public void release() { drag = -1; }
    }

    // ------------------------------------------------------------------ colour presets

    public static class PresetsRow extends Row {
        private static final String[] NAMES = {"Mint", "Violet", "Ice", "Sunset", "Crimson"};
        private static final int[][] COLS = {
                {0xFFC8F7D4, 0xFFFFFFFF, 0xFFFF8CC0},
                {0xFF8A5CFF, 0xFF35D6FF, 0xFFFF4D9D},
                {0xFF9FE8FF, 0xFF4D8DFF, 0xFFFFE066},
                {0xFFFF7A45, 0xFFFF3D8A, 0xFF5CE1FF},
                {0xFFFF3B4A, 0xFFB000FF, 0xFF4DFFB8}
        };

        public PresetsRow(L label, L desc) { super(label, desc); }

        @Override protected int rightW() { return 0; }
        @Override public int height() { return 44 + 40; }

        private int bw() { return (w - PAD * 2 - (NAMES.length - 1) * 8) / NAMES.length; }
        private int by() { return y + 40; }

        @Override protected void drawControl(DrawContext ctx, int mx, int my) {
            int bw = bw(), by = by();
            for (int i = 0; i < NAMES.length; i++) {
                int bx = x + PAD + i * (bw + 8);
                boolean hv = mx >= bx && mx < bx + bw && my >= by && my < by + 28;
                Gfx.rrect(ctx, bx, by, bw, 28, 8, hv ? 0xFFFFFFFF : 0xFF1B1C33);
                Gfx.rrect(ctx, bx + 2, by + 2, bw - 4, 24, 6, COLS[i][0]);
                Gfx.hgrad(ctx, bx + 6, by + 2, bw - 12, 24, COLS[i][0], COLS[i][1]);
                Gfx.ctext(ctx, NAMES[i], bx + bw / 2f, by + 14 - Gfx.CAP * 1.15f / 2f, 1.15f, 0xFF101018, true);
            }
        }

        @Override public boolean click(double mx, double my, int btn) {
            if (btn != 0 || my < by() || my >= by() + 28) return false;
            int bw = bw();
            for (int i = 0; i < NAMES.length; i++) {
                int bx = x + PAD + i * (bw + 8);
                if (mx >= bx && mx < bx + bw) {
                    Config c = Config.get();
                    c.colorA = COLS[i][0];
                    c.colorB = COLS[i][1];
                    c.invisibleColor = COLS[i][2];
                    return true;
                }
            }
            return false;
        }
    }
}
